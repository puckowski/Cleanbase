var https = require('https');
var url = require('url');
var fs = require('fs');
var cp = require('child_process');


const serverOptions = {
	key: fs.readFileSync('key.pem'),
	cert: fs.readFileSync('cert.pem')
};

https.createServer(serverOptions, async function (req, res) {
    var url_parts = url.parse(req.url);
    console.log(url_parts);

    if (req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('Hello, World CUSTOM END!\n');
    } else {
        res.writeHead(405, { 'Content-Type': 'text/plain' });
        res.end('Method Not Allowed END 2 \n');
    }

}).listen(80, '0.0.0.0');
console.log('Server running.');

