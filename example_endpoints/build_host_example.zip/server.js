var https = require('https');
var url = require('url');
var fs = require('fs');
var cp = require('child_process');

const serverOptions = {
	key: fs.readFileSync('key.pem'),
	cert: fs.readFileSync('cert.pem')
};

https.createServer(serverOptions, async function (req, res) {
	var url_parts = url.parse(req.url);
	console.log(url_parts);

	if (req.method === 'GET') {
		var postData = JSON.stringify({
			"key": "123456",
			"jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImFiY2RlZmciLCJ1c2VyX2lkIjoxLCJzZXJ2aWNlX2lkIjoxLCJpYXQiOjE2NTA0OTA4MjgsImV4cCI6MTY1MDQ5MTcyOH0.GUpK78Im8UIO9I6mAvHB2FZoTc0a0HKqQTjQcOXRnS"
		});

		var options = {
			protocol: 'https:',
			hostname: '172.17.0.1',
			port: 443,
			path: '/validatejwt/roottest',
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'Content-Length': postData.length
			},
			rejectUnauthorized: false,
			requestCert: true,
			agent: false
		};

		var req2 = https.request(options, (result) => {
			console.log('statusCode:', result.statusCode);
			console.log('headers:', result.headers);

			result.on('data', (d) => {
				// process.stdout.write(d);
				res.writeHead(200, { 'Content-Type': 'text/plain' });
				res.end(d);
			});
		});

		req2.on('error', (e) => {
			console.error(e);
			res.writeHead(200, { 'Content-Type': 'text/plain' });
			res.end('error');
		});

		req2.write(postData);
		req2.end();
	} else {
		res.writeHead(405, { 'Content-Type': 'text/plain' });
		res.end('Method Not Allowed END 2 \n');
	}
}).listen(80, '0.0.0.0');
console.log('Server running.');
